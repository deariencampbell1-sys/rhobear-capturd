# @rhobear/family-kit

The shared implementation home for the Rhobear family of apps: tokens, fonts, marks, motion, React and native
surfaces, and the shared graph model/renderer. The package is private to the family and is consumed by the app and
board lanes.

## Surfaces

| Import | State | Brief |
|---|---|---|
| `@rhobear/family-kit` | built — `VERSION` and `SOURCE_SHA` | W0-01 |
| `@rhobear/family-kit/tokens` | built — `skins`, `products`, `engines`, `geometry`, `semantic` | W0-01 |
| `@rhobear/family-kit/tokens.css` | built — locked Builds blocks plus `--rb-*` geometry and state tokens | W0-01 |
| `@rhobear/family-kit/fonts` | not built | W0-02 |
| `@rhobear/family-kit/fonts.css` | not built — placeholder stylesheet only | W0-02 |
| `@rhobear/family-kit/marks` | not built | W0-03 |
| `@rhobear/family-kit/motion` | stylesheet built — `./motion.css`; the JS surface lands with `W1-01b` | W1-01a |
| `@rhobear/family-kit/motion.css` | built — `--rb-motion-*` durations and easings, `.rb-work` | W1-01a |
| `@rhobear/family-kit/react` | not built | W1-02 |
| `@rhobear/family-kit/native` | not built | W1-04 |
| `@rhobear/family-kit/graph` | not built | W2-01 |
| `@rhobear/family-kit/graph/draw` | not built | W2-04 |
| `@rhobear/family-kit/graph/editor` | not built | W3-03 |
| `@rhobear/family-kit/graph/views` | not built | W4-02 |
| `@rhobear/family-kit/graph/export` | not built | W4-01 |
| `@rhobear/family-kit/graph/execution` | not built | W5-01 |

A not-built surface exports `status = "not-built"` and a `require<Surface>()` function that throws `NotBuiltError`
with the brief id. It never returns placeholder data.

## Pin the package

The package is `private: true`, unpublished, and lives at `packages/family-kit` inside this monorepo. It is not on a
registry, so there is no version to pin and no working `git+https://…/rhobear-north-star#<sha>` dependency: npm
installs a git dependency from the repository root, and this repository's root has no `package.json`. Do not point a
dependency at the monorepo URL.

A consumer in this repo links the package as a workspace or `file:` dependency:

```json
"dependencies": {
  "@rhobear/family-kit": "file:../family-kit"
}
```

A consumer outside this repo must copy or clone the `packages/family-kit` subtree and install that copy with a `file:`
path. Pin the copy to a full commit SHA of this repo, store that SHA beside the dependency, and compare it with the
runtime `SOURCE_SHA`; never use a floating ref such as `latest`, a branch, or a range. The package stays `private`
until it is published; once it is published or split into its own repository, pin its tarball or a full commit SHA.

`prepare` builds `dist/` for `file:` dependency installs when git `HEAD` or `SOURCE_SHA`/`GIT_SHA` is available. If
your npm did not run `prepare` for a `file:` or workspace dependency, run `npm run build` once in
`packages/family-kit` (with `SOURCE_SHA` set if the checkout has no `.git`) before importing it.

At runtime the package exposes the exact source revision it was built from:

```js
import { VERSION, SOURCE_SHA } from "@rhobear/family-kit";
```

Store the expected version and `SOURCE_SHA` beside the dependency and fail the consumer build when either changes.
Graph snapshots additionally pin their `schemaVersion` and `rendererVersion` when those surfaces exist.

### Installing from a copy without `.git`

The build stamps the source revision into `dist/version.js` and the `tokens.css` header, and it refuses to stamp a
placeholder revision. `prepare` runs during install and builds when it can resolve a revision. A consumer, CI image,
or Docker build that copies the package without a `.git` directory must provide the revision explicitly:

```sh
SOURCE_SHA=<40-char-commit-sha> npm ci
```

`prepare` then builds `dist/` as part of the install. A plain `npm ci` in a git-less copy still succeeds but skips the
build with a warning; build afterwards, before importing the package:

```sh
npm ci
SOURCE_SHA=<40-char-commit-sha> npm run build
```

`npm ci --ignore-scripts` skips every lifecycle script, including `prepare`; run the same manual
`SOURCE_SHA=<40-char-commit-sha> npm run build` afterwards.

`SOURCE_SHA` (or `GIT_SHA`) must be the 40-character lowercase hex SHA of the copied source. When git can resolve
`HEAD`, an override must equal it, or the build fails with both SHAs in the message; an unchecked override is only
accepted when git cannot resolve `HEAD` at all.

**Migration:** a build in a source snapshot with neither git `HEAD` nor `SOURCE_SHA`/`GIT_SHA` now fails instead of
stamping an "unknown" revision. If a packaging step relied on that placeholder, set the revision, or let `prepare`
skip the build and run `SOURCE_SHA=<sha> npm run build` when the revision is known.

## Tokens

`tokens.css` re-emits every locked source block under its original selector and property names. The rho-ui kit blocks
are the canonical base. The locked per-app theme blocks are emitted inside `@layer family-kit.app-sources` as
**provenance only**: kit `:root` declarations are unlayered, so they always win over the layered app blocks, and
importing `tokens.css` on a bare root yields the midnight base. Importing the stylesheet does not make a Builds page
inherit forge's accent or any other per-app value; all product theming comes from the `/tokens` data exports
(`products[*].accent`, `skins`, and the rest), not from CSS cascade inheritance. **Colours keep their Builds names; new
geometry uses `--rb-*`.** Colours keep their Builds names exactly; `--f-*` values pass through
`src/tokens/font-rewrite.json` because the boards still declare JetBrains Mono and Manrope, and the kit never ships a
banned face.
The additions are:

- `--rb-space-*`, `--rb-type-*-size`, `--rb-type-*-lh`, `--rb-radius-*`, `--rb-min-hit`, `--rb-focus-ring`
- `--rb-state-{waiting,success,warning,error}-{dark,light}` for semantic state text

The JavaScript `/tokens` entry exports the same data as typed objects, including the five skins, high contrast, the
product accents, the eleven Engines overrides, and the geometry map. `src/tokens/source.json` is the extracted record
with the source commit and file hashes. Run `npm run extract` to refresh it; `--check` proves it is unchanged. The
extractor accepts `FAMILY_KIT_REPO_ROOT`, `FAMILY_KIT_REFERENCE`, and `FAMILY_KIT_OUTPUT` to point at a temporary
root, reference, and output, but those path overrides are **test-only**: they are honored only when `NODE_ENV=test`
and are ignored with a warning otherwise. By default it reads the in-repo reference and writes the committed
`source.json`.

## Source boundary

`outputs/rho-ux-flows/` and the family board files are read-only sources, not consumers. The extractor reads them and
checks their hashes against `docs/north-star/lanes/L3-kit/tokens-reference.json`; nobody edits a source to make this
package pass. The locked references stay locked.

The full lane contract, including authority boundaries and the colour table, is
[`docs/north-star/lanes/L3-kit/CONTRACT.md`](../../docs/north-star/lanes/L3-kit/CONTRACT.md).

## Motion

`@rhobear/family-kit/motion.css` carries one motion vocabulary for every app in the family. Every duration and easing
is verbatim from `docs/north-star/lanes/L3-kit/CONTRACT.md` (lines 175–188); the table and the stylesheet are held in
agreement by `test/motion-tokens.test.mjs`, so a value that drifts in either file fails the suite.

```css
@import "@rhobear/family-kit/motion.css";

.act      { transition: background var(--rb-motion-appear-dur) var(--rb-motion-appear-ease); }
.act-more { transition: grid-template-rows var(--rb-motion-disclose-dur) var(--rb-motion-disclose-ease); }
.sheet    { transition: transform var(--rb-motion-sheet-dur) var(--rb-motion-sheet-ease); }
.scrim    { transition: opacity var(--rb-motion-sheet-scrim-dur); }
```

| Token | Duration | Easing | Also |
|---|---|---|---|
| `press` | `--rb-motion-press-dur` | `-ease` | release hold 90 ms |
| `appear` | `--rb-motion-appear-dur` | `-ease` | |
| `disclose` | `--rb-motion-disclose-dur` | `-ease` | |
| `sheet` | `--rb-motion-sheet-dur` | `-ease` | scrim 300 ms |
| `toggle` | `--rb-motion-toggle-dur` | `-ease` | background 200 ms |
| `working` | `--rb-motion-working-dur` | `-ease` | 1600 ms, linear |
| `scroll-hint` | `--rb-motion-scroll-hint-dur` | `-ease` | fade 600 ms |
| `quantity` | `--rb-motion-quantity-dur` | `-ease` | |
| `glass-sheen` | `--rb-motion-glass-sheen-dur` | `-ease` | 5 s cycle, decorative |
| `push` `pop` | `--rb-motion-push-dur` `-pop-dur` | `-ease` | crossfade 120 ms under reduced motion |
| `toast` | `--rb-motion-toast-dur` | `-ease` | out 160 ms, auto-hide 4 s |
| `nudge` | `--rb-motion-nudge-dur` | `-ease` | |
| `portal-gas` | — (behaviour only) | `--rb-motion-portal-gas-ease` | |

**The working label.** `.rb-work` runs a light *through the words* (`background-clip: text`), never a rectangle over a
button. Every stop of the gradient falls back to a **plain colour** — `currentColor` — so it is readable in a theme that
defines none of the three variables. A fallback that is itself a newer CSS function (such as `color-mix()`) would not be
a fallback at all: an invalid substitution drops the whole gradient and the transparent text fill would then paint
nothing. The brighter sheen is added in a separate `@supports (color: color-mix(in srgb, white, black))` block, so an
engine without `color-mix()` still paints a readable label:

```css
:root { --sweep-base: #e8ecf3; --sweep-mid: #8a93a3; --sweep-hi: #ffffff; }
```

**Reduced motion is data.** Importing the stylesheet gives you two paths — `@media (prefers-reduced-motion: reduce)` and
`:root[data-motion=reduce]` — that zero every duration, stop the kit's own animations, keep colour and text feedback, and
keep the `push`/`pop` crossfade the contract asks for. The kill rule is scoped to `.rb-work` and `[data-rb-motion]` on
purpose: importing a stylesheet must never disable animation for the app around it.

`[data-rb-motion]` is only matched **inside** those two reduced-motion paths — it is a marker the app puts on a wrapper
to say "the kit's components live here", so their animations and transitions are stopped along with the kit's own. It
does nothing on its own and it does not opt anything in when motion is allowed.

## Development

```sh
npm ci
npm run extract
npm test
```

`npm run build` runs `tsc`, generates `dist/tokens/tokens.css`, `dist/tokens/index.js`, and `dist/version.js`, then
copies `src/**/*.css` and `src/**/*.json` into `dist/` at the same relative paths. `prepack` builds a tarball for
`npm pack` and `npm publish`; `prepare` builds for `file:` dependency installs (and for a git dependency when the
package's `package.json` is at that repository's root) when git `HEAD` or `SOURCE_SHA`/`GIT_SHA` is available.
`npm pack` builds exactly once: `prepack` writes `dist/`, then `prepare` sees
`dist/version.js` is current and exits without rebuilding. A plain `npm ci` in a git-less copy skips the build with a
warning; set `SOURCE_SHA` as described above or build manually. `sharp`, `fontkit`, and `png-to-ico` are pinned ahead
of the W0-02 fonts and W0-03 marks surfaces that will use them; no current build or test imports them.
