name: "Girassol"
designer: "Liam Spradlin"
license: "OFL"
category: "DISPLAY"
date_added: "2019-12-05"
fonts {
  name: "Girassol"
  style: "normal"
  weight: 400
  filename: "Girassol-Regular.ttf"
  post_script_name: "Girassol-Regular"
  full_name: "Girassol Regular"
  copyright: "Copyright 2019 The Girassol Project Authors (https://github.com/liamspradlin/Girassol-Display)"
}
subsets: "latin"
subsets: "latin-ext"
subsets: "menu"
source {
  repository_url: "https://github.com/liamspradlin/Girassol-Display"
  commit: "cc8fa1b5a1afc28520fdc0ccc36256db243d9dfa"
}
stroke: "SERIF"
classifications: "DISPLAY"
