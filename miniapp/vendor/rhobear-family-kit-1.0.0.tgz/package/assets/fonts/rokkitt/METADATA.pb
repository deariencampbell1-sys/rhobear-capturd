name: "Rokkitt"
designer: "Vernon Adams"
license: "OFL"
category: "SERIF"
date_added: "2011-07-27"
fonts {
  name: "Rokkitt"
  style: "normal"
  weight: 400
  filename: "Rokkitt[wght].ttf"
  post_script_name: "Rokkitt-SemiBold"
  full_name: "Rokkitt SemiBold"
  copyright: "Copyright 2016 The Rokkit Project Authors (https://github.com/googlefonts/RokkittFont)"
}
fonts {
  name: "Rokkitt"
  style: "italic"
  weight: 400
  filename: "Rokkitt-Italic[wght].ttf"
  post_script_name: "Rokkitt-SemiBoldItalic"
  full_name: "Rokkitt SemiBold Italic"
  copyright: "Copyright 2016 The Rokkit Project Authors (https://github.com/googlefonts/RokkittFont)"
}
subsets: "latin"
subsets: "latin-ext"
subsets: "menu"
subsets: "vietnamese"
axes {
  tag: "wght"
  min_value: 100.0
  max_value: 900.0
}
source {
  repository_url: "https://github.com/Fonthausen/RokkittFont"
  commit: "762d1439aaa7cf4a590f604451dfc2e1c6970b9f"
  files {
    source_file: "OFL.txt"
    dest_file: "OFL.txt"
  }
  files {
    source_file: "fonts/variable/Rokkitt-Italic[wght].ttf"
    dest_file: "Rokkitt-Italic[wght].ttf"
  }
  files {
    source_file: "fonts/variable/Rokkitt[wght].ttf"
    dest_file: "Rokkitt[wght].ttf"
  }
  branch: "master"
  config_yaml: "sources/config.yaml"
}
stroke: "SLAB_SERIF"
